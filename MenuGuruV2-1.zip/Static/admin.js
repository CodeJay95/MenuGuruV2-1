const menuItemForm = document.getElementById('menu-item-form');
const itemNameInput = document.getElementById('item-name');
const allergensSelect = document.getElementById('allergens');
const addButton = document.getElementById('add-item');
const updateButton = document.getElementById('update-item');
const cancelButton = document.getElementById('cancel');
const menuItemsList = document.getElementById('menu-items').getElementsByTagName('ul')[0];

let editingMenuItemId = null;

// Fetch the menu items from the API and display them
fetchMenuItems();

addButton.addEventListener('click', (e) => {
  e.preventDefault();
  createMenuItem();
});

updateButton.addEventListener('click', (e) => {
  e.preventDefault();
  updateMenuItem();
});

cancelButton.addEventListener('click', (e) => {
  e.preventDefault();
  clearForm();
});

function fetchMenuItems() {
  // Replace with the actual API endpoint URL
  fetch('/api/menu_items')
    .then((response) => response.json())
    .then((menuItems) => {
      menuItemsList.innerHTML = '';
      menuItems.forEach((menuItem) => {
        addMenuItemToList(menuItem);
      });
    });
}

function createMenuItem() {
  const itemName = itemNameInput.value.trim();
  const allergens = Array.from(allergensSelect.selectedOptions).map((option) => option.value);

  if (!itemName || !allergens.length) {
    alert('Please fill in all the required fields.');
    return;
  }

  // Replace with the actual API endpoint URL
  fetch('/api/menu_items', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ name: itemName, allergens }),
  })
    .then((response) => response.json())
    .then((menuItem) => {
      addMenuItemToList(menuItem);
      clearForm();
    });
}

function updateMenuItem() {
  if (!editingMenuItemId) {
    alert('No menu item is being edited.');
    return;
  }

  const itemName = itemNameInput.value.trim();
  const allergens = Array.from(allergensSelect.selectedOptions).map((option) => option.value);

  if (!itemName || !allergens.length) {
    alert('Please fill in all the required fields.');
    return;
  }

  // Replace with the actual API endpoint URL
  fetch(`/api/menu_items/${editingMenuItemId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ name: itemName, allergens }),
  })
    .then((response) => response.json())
    .then((menuItem) => {
      const menuItemElement = document.getElementById(`menu-item-${menuItem.id}`);
      menuItemElement.textContent = menuItem.name;
      clearForm();
    });
}

function deleteMenuItem(id) {
  // Replace with the actual API endpoint URL
  fetch(`/api/menu_items/${id}`, {
    method: 'DELETE',
  }).then(() => {
    const menuItemElement = document.getElementById(`menu-item-${id}`);
    menuItemElement.parentElement.removeChild(menuItemElement);
  });
}

function editMenuItem(id, name, allergens) {
  editingMenuItemId = id;
  itemNameInput.value = name;

  Array.from(allergensSelect.options).forEach((option) => {
    option.selected = allergens.includes(option.value);
  });
}

function addMenuItemToList(menuItem) {
  const listItem = document.createElement('li');
  listItem.id = `menu-item-${menuItem.id}`;
  listItem.textContent = menuItem.name;
  const editButton = document.createElement('button');
  editButton.textContent = 'Edit';
  editButton.addEventListener('click', () => {
    editMenuItem(menuItem.id, menuItem.name, menuItem.allergens);
  });

  const deleteButton = document.createElement('button');
  deleteButton.textContent = 'Delete';
  deleteButton.addEventListener('click', () => {
    deleteMenuItem(menuItem.id);
  });

  listItem.appendChild(editButton);
  listItem.appendChild(deleteButton);
  menuItemsList.appendChild(listItem);
}

function clearForm() {
  itemNameInput.value = '';
  allergensSelect.selectedIndex = -1;
  editingMenuItemId = null;
  addButton.style.display = 'inline';
  updateButton.style.display = 'none';
  cancelButton.style.display = 'none';
}
