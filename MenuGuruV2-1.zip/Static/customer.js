const allergenFilter = document.getElementById("allergen-filter");
const menuItemsList = document.getElementById("menu-items").getElementsByTagName("ul")[0];

let menuItems = [];

// Fetch the menu items from the API and display them
fetchMenuItems();

document.getElementById("apply-filter").addEventListener("click", () => {
  filterMenuItems();
});

function fetchMenuItems() {
  // Replace with the actual API endpoint URL
  fetch("/api/menu_items")
    .then((response) => response.json())
    .then((data) => {
      menuItems = data;
      displayMenuItems(menuItems);
    });
}

function displayMenuItems(items) {
  menuItemsList.innerHTML = "";
  items.forEach((item) => {
    const listItem = document.createElement("li");
    listItem.textContent = item.name;
    menuItemsList.appendChild(listItem);
  });
}

function filterMenuItems() {
  const selectedAllergens = Array.from(allergenFilter.selectedOptions).map(
    (option) => option.value
  );

  const filteredItems = menuItems.filter((item) =>
    selectedAllergens.every((allergen) => !item.allergens.includes(allergen))
  );

  displayMenuItems(filteredItems);
}
