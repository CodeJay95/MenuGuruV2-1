from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
import enum

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///allergy_menu.db'
app.secret_key = 'your_secret_key'
db = SQLAlchemy(app)

class Allergen(enum.Enum):
    CELERY = "Celery"
    CRUSTACEANS = "Crustaceans"
    EGGS = "Eggs"
    FISH = "Fish"
    GLUTEN = "Gluten"
    LUPIN = "Lupin"
    MILK = "Milk"
    MOLLUSCS = "Molluscs"
    MUSTARD = "Mustard"
    NUTS = "Nuts"
    PEANUTS = "Peanuts"
    SESAME = "Sesame"
    SOYBEANS = "Soybeans"
    SULFITE = "Sulfite"

class Restaurant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    menu_items = db.relationship('MenuItem', backref='restaurant', lazy=True)

class MenuItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(200), nullable=True)
    category = db.Column(db.String(50), nullable=False)
    allergens = db.Column(db.String(200), nullable=True)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurant.id'), nullable=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        # Perform login validation here
        return redirect(url_for('add_dish'))
    else:
        return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/customer_menu')
def customer_menu():
    return render_template('customer_menu.html')

@app.route('/api/menu_items', methods=['GET'])
def get_menu_items():
    menu_items = MenuItem.query.all()
    return jsonify([{"id": item.id, "name": item.name, "allergens": item.allergens} for item in menu_items])

@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)

@app.route('/api/menu_items', methods=['POST'])
def create_menu_item():
    data = request.get_json()
    new_item = MenuItem(name=data["name"], allergens=','.join(data["allergens"]))
    db.session.add(new_item)
    db.session.commit()
    return jsonify({"id": new_item.id, "name": new_item.name, "allergens": new_item.allergens})

@app.route('/api/menu_items/<int:item_id>', methods=['PUT'])
def update_menu_item(item_id):
    data = request.get_json()
    item = MenuItem.query.get(item_id)
    item.name = data["name"]
    item.allergens = ','.join(data["allergens"])
    db.session.commit()
    return jsonify({"id": item.id, "name": item.name, "allergens": item.allergens})

@app.route('/api/menu_items/<int:item_id>', methods=['DELETE'])
def delete_menu_item(item_id):
    item = MenuItem.query.get(item_id)
    db.session.delete(item)
    db.session.commit()
        return jsonify({"result": "success"})

@app.route('/admin/add_dish', methods=['GET', 'POST'])
def add_dish():
    if request.method == 'POST':
        dish_name = request.form['dish_name']
        description = request.form['description']
        category = request.form['category']
        allergens_list = request.form.getlist('allergens')
        allergens = ','.join(allergens_list)

        # Replace 1 with the actual restaurant_id you want to assign to the dish
        new_dish = MenuItem(name=dish_name, description=description, category=category, allergens=allergens, restaurant_id=1)
        db.session.add(new_dish)
        db.session.commit()

        flash("Dish added successfully!", "success")
        return redirect(url_for('add_dish'))

    else:
        allergens = [allergen.value for allergen in Allergen]
        return render_template('add_dish.html', allergens=allergens)

if __name__ == '__main__':
    app.run(debug=True, port=8080)

if __name__ == "__main__":
  app.run()
